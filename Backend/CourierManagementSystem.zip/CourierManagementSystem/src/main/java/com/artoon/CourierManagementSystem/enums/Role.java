package com.artoon.CourierManagementSystem.enums;

public enum Role {
    CUSTOMER,
    ADMIN,
    MANAGER,
    DELIVERY_AGENT
}
