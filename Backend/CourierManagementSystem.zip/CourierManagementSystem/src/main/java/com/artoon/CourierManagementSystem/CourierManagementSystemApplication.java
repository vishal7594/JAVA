package com.artoon.CourierManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourierManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourierManagementSystemApplication.class, args);
	}

}
